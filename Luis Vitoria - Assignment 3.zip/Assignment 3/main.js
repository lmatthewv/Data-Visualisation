let map;
let europeMap;
let russiaMap;
let medal;
let table;
let x;
let y;
let country;
var europe = 0;
var number = 0;
var europeMedals = 0;
var count = 0;
var showMap = 0;

//Preloading images and table
function preload() {
  map = loadImage('assets/MapText.png');
  medal = loadImage('assets/goldmedal.png');
  europeMap = loadImage('assets/EuropeNoText.png');
  russiaMap = loadImage('assets/RussiaInteract.png');
  table = loadTable('assets/MOCK_DATA.csv', 'csv', 'header');
}

function setup() {
  //Draws the original map chart
  drawMap();
}

function draw() {
  //Checks if the european map is selected
  if (showMap == 1) {
    //Display the european map graphic with a border
    stroke(0);
    strokeWeight(10);
    rect(455, 35, europeMap.width, europeMap.height);
    noStroke();
    image(europeMap, 455, 35);
    for (let r = 0; r < table.getRowCount(); r++) {
      for (let c = 0; c < table.getColumnCount(); c++) {
        number = parseInt(table.getString(r, 2));
        x = parseInt(table.getString(r, 3));
        y = parseInt(table.getString(r, 4));
        europe = parseInt(table.getString(r, 5));
      }
      if(europe == 1) {
        drawEuropeanMedal(x,y,number, europe);
      }
    }
  //Checks if the Russian medal graphic has been selected
  } else if (showMap == 2) {
    //Display the Russian interaction graphic
    image(russiaMap, 770, 50, 700, 350);
  }
}

function drawMap() {
  //create the canvas
  createCanvas(1920, 1080);
  background(50);

  europeMedals = 0
  //Load the map image to the canvas
  image(map, 5, 5);
    //Loop through the table rows and columns
    for (let r = 0; r < table.getRowCount(); r++) {
      for (let c = 0; c < table.getColumnCount(); c++) {
        //Parse table information into each variable
        number = parseInt(table.getString(r, 2));
        x = parseInt(table.getString(r, 3));
        y = parseInt(table.getString(r, 4));
        europe = parseInt(table.getString(r, 5));
      }
      //Draw the medal graphic for each row.
      drawMedal(x,y,number, europe);
    }
}

function mouseClicked() {
  //If the mouse is clicked when hovering over Europe
  if (mouseX > 650 && mouseX < 870 && mouseY > 120 && mouseY < 340) {
    //Display the european map
    showMap = 1;
  //If the mouse is clicked while hovering over the Russian medal graphic
  }  else if(mouseX > 1012 && mouseX < 1112 && mouseY > 140 && mouseY < 240) {
    //Show the Russian interaction graphic
    showMap = 2;
  } else {
    //If the mouse is clicked on any other part of the chart the canvas 
    //will be cleared and the original map chart is displayed
    showMap = 0;
    clear();
    drawMap();
  }
}

function drawMedal(x, y, number, europe) {
  //If the row has been designated as a european country.
  if (europe == 1) {
    //Calculate the total medal count and display the final medal graphic.
    europeMedals += number;
    image(medal, 710, 220, 80, 80);
    textSize(20);
    textStyle(BOLD);
    text(europeMedals, 728, 280);
  //If the number of gold medals is a 1 digit number
  } else if (number < 10 && number > 0){
    //Display the medal graphic with text to fit
    textStyle(NORMAL);
    image(medal, x, y, 50, 50);
    textSize(24);
    text(number, x + 19, y + 41);
  //If the number of gold medals is a 2 digit number
  } else if (number < 100 && number > 9) {
    //Display the medal graphic with text to fit
    textStyle(NORMAL);
    image(medal, x, y, 50, 50);
    textSize(24);
    text(number, x + 12, y + 41);
  //If the number of gold medals is a 3 digit number
  } else if(number > 99 && number < 1000) {
    //Display the medal graphic with text to fit
    image(medal, x, y, 80, 80);
    textSize(24);
    textStyle(BOLD);
    text(number, x + 21, y + 61);
  //If the number of gold medals is a 4 digit number
  } else if(number > 999) {
    //Display the medal graphic with text to fit
    image(medal, x, y, 80, 80);
      textSize(20);
      textStyle(BOLD);
      text(number, x + 19, y + 60);
  }
}

  function drawEuropeanMedal(x, y, number, europe) {
    //If the number of gold medals is a 1, 2 or 3 digit number
    //Display the medal graphic with text to fit
    if (number < 10 && number > 0){
      textStyle(NORMAL);
      image(medal, x, y, 50, 50);
      textSize(24);
      text(number, x + 19, y + 41);
    } else if (number < 100 && number > 9) {
      textStyle(NORMAL);
      image(medal, x, y, 50, 50);
      textSize(24);
      text(number, x + 12, y + 41);
    } else if(number > 99 && number < 1000) {
      image(medal, x, y, 80, 80);
      textSize(24);
      textStyle(BOLD);
      text(number, x + 21, y + 61);
    }
}